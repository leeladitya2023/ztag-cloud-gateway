# ZTAG Cloud Gateway
A sample Zero Trust Gateway using Flask, gRPC, RabbitMQ, and Kubernetes.