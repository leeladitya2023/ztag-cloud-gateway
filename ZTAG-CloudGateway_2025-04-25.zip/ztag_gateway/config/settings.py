# Configuration for gateway
