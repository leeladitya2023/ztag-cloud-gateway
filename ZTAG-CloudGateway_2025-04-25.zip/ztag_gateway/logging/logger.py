# Logger using RabbitMQ
